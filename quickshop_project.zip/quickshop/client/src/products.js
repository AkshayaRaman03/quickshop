
const products = [
  {
    id: 1,
    title: "T-shirt",
    price: 1999,
    imageURL: "https://via.placeholder.com/150",
    description: "A comfortable cotton T-shirt."
  },
  {
    id: 2,
    title: "Jeans",
    price: 3999,
    imageURL: "https://via.placeholder.com/150",
    description: "Blue denim jeans."
  },
  {
    id: 3,
    title: "Sneakers",
    price: 5999,
    imageURL: "https://via.placeholder.com/150",
    description: "Trendy sneakers."
  },
];
export default products;
