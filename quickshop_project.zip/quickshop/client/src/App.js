
import { useState } from 'react';
import products from './products';
import axios from 'axios';

function App() {
  const [cart, setCart] = useState([]);

  const addToCart = (product) => {
    const existing = cart.find(item => item.id === product.id);
    if (existing) {
      setCart(cart.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item));
    } else {
      setCart([...cart, { ...product, quantity: 1 }]);
    }
  };

  const removeFromCart = (id) => {
    setCart(cart.filter(item => item.id !== id));
  };

  const updateQuantity = (id, qty) => {
    setCart(cart.map(item => item.id === id ? { ...item, quantity: qty } : item));
  };

  const getTotal = () => {
    return cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  };

  const checkout = async () => {
    const email = prompt("Enter your email for confirmation:");
    const res = await axios.post('http://localhost:4000/create-checkout-session', {
      items: cart,
      email
    });
    window.location = res.data.url;
  };

  return (
    <div className="p-4">
      <h1>QuickShop</h1>
      <div style={{ display: "flex", gap: "20px" }}>
        {products.map(product => (
          <div key={product.id} style={{ border: "1px solid black", padding: "10px" }}>
            <img src={product.imageURL} alt={product.title} width="100" />
            <h2>{product.title}</h2>
            <p>${(product.price/100).toFixed(2)}</p>
            <button onClick={() => addToCart(product)}>Add to Cart</button>
          </div>
        ))}
      </div>
      <hr />
      <h2>Cart</h2>
      {cart.length === 0 && <p>No items in cart</p>}
      {cart.map(item => (
        <div key={item.id}>
          {item.title} x 
          <input type="number" value={item.quantity} min="1"
            onChange={e => updateQuantity(item.id, parseInt(e.target.value))} style={{width: "50px"}}/>
          <button onClick={() => removeFromCart(item.id)}>Remove</button>
        </div>
      ))}
      <h3>Total: ${(getTotal()/100).toFixed(2)}</h3>
      {cart.length > 0 && <button onClick={checkout}>Checkout</button>}
    </div>
  );
}
export default App;
